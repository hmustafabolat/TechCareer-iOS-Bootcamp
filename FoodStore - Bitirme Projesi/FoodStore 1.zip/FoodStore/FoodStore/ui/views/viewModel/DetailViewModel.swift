//
//  DetailViewModel.swift
//  FoodStore
//
//  Created by Musti on 10.10.2023.
//

import Foundation
import RxSwift

class DetailViewModel{
    var frepo = FoodStoreDaoRepository()
    
    var foodCount = BehaviorSubject<Int>(value: 1)
    var totalPrice = BehaviorSubject<Int>(value: 0)
    var cartList = BehaviorSubject<[CartFoodModel]>(value: [CartFoodModel]())
    var foodDetail: [String] = ["Ayran, yoğurt, su ve tuzun karıştırılmasıyla elde edilen geleneksel bir içecektir.",
    "İnce yufka hamurları arasına döşenmiş ceviz, fıstık veya antep fıstığı karışımı ile yapılan bir tatlıdır.",
    "Fanta, dünya genelinde popüler olan bir gazlı içecektir. İlk kez 1940 yılında Almanya'da üretildi ve Coca-Cola Company tarafından pazarlandı",
    "Izgara somon, popüler bir deniz ürünü yemeğidir ve somon balığının lezzetli bir şekilde hazırlanmış bir versiyonudur.",
    "Izgara tavuk, tavuk etinin ızgarada pişirilerek hazırlandığı bir yemektir.",
    "Kadayıf, ince tel tel doğranmış hamurla yapılan bir tatlıdır ve özellikle Orta Doğu, Balkanlar ve Türkiye'de popülerdir",
    "Kahve, kahve çekirdeklerinin öğütülüp suyla demlenmesi sonucu elde edilen popüler bir içecektir.",
    "Köfte, dünya genelinde birçok kültürde popüler olan, et veya et yerine bitkisel malzemeler kullanılarak yapılan yuvarlak veya yassı şekilli yiyeceklerdir.",
    "Lazanya, İtalyan mutfağının lezzetli ve popüler bir yemeğidir.",
    "Makarna, dünya genelinde popüler olan ve çok çeşitli biçimlerde ve soslarla hazırlanabilen bir yiyecektir.",
    "Pizza, İtalyan kökenli bir yemek olup dünya genelinde popülerliği yüksek olan bir yiyecektir. ",
    "Su, yaşam için vazgeçilmez bir elementtir ve dünya üzerindeki tüm canlı organizmalar için hayati bir öneme sahiptir. ",
    "Sütlaç, Türk mutfağının geleneksel tatlılarından biridir. ",
    "Tiramisu, İtalyan mutfağının ünlü bir tatlısıdır.",
                            
    ]
    
    init (){
        totalPrice = frepo.totalPrice
        foodCount = frepo.foodCount
        cartList = frepo.cartList
    }
    func sepeteYemekEkle(yemek_adi: String, yemek_resim_adi: String, yemek_fiyat: Int, yemek_siparis_sayisi: Int, kullanici_adi: String ){
        frepo.sepeteYemekEkle(yemek_adi: yemek_adi, yemek_resim_adi: yemek_resim_adi, yemek_fiyat: yemek_fiyat, yemek_siparis_sayisi: yemek_siparis_sayisi, kullanici_adi: kullanici_adi)
    }
    
    func detaydaAdetSec(){
        
    }
    
    func sepettenYemekSil(sepet_yemek_id: Int, kullanici_adi: String) {
        frepo.sepettenYemekSil(sepet_yemek_id: sepet_yemek_id, kullanici_adi: kullanici_adi)
    }
    
    func sepettekiYemekleriGoruntule(kullanici_adi: String) {
        frepo.sepettekiYemekleriGoruntule(kullanici_adi: kullanici_adi)
    }
    
    func increaseFoodCount() {
        frepo.increaseFoodCount()
    }
    
    func decreaseFoodCount() {
        frepo.decreaseFoodCount()
    }
    
    func calculatePrice(price: Int) {
        frepo.calculatePrice(price: price)
    }

    
}
