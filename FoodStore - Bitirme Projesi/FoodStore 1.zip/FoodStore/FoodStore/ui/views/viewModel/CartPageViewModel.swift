//
//  CartPageViewModel.swift
//  FoodStore
//
//  Created by Musti on 6.10.2023.
//

import Foundation
import RxSwift

class CartPageViewModel{
    var frepo = FoodStoreDaoRepository()
    
}
