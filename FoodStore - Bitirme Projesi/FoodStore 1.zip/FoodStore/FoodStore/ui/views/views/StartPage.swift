//
//  StartPage.swift
//  FoodStore
//
//  Created by Musti on 5.10.2023.
//

import UIKit

class StartPage: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    
}
