//
//  FoodDetailModel.swift
//  FoodStore
//
//  Created by Musti on 16.10.2023.
//

import Foundation

struct FoodDetailModel{
    let food: FoodsModel
    let index: Int
}
