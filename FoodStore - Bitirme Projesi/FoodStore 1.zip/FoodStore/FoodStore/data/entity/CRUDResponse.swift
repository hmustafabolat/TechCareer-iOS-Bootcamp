//
//  CRUDResponse.swift
//  FoodStore
//
//  Created by Musti on 6.10.2023.
//

import Foundation

class CRUDResponse : Codable {
    var success:Int?
    var message:String?  
}
