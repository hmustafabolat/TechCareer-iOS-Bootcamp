//
//  CRUDCevap.swift
//  KisilerUygulamasi
//
//  Created by Kasım on 1.10.2023.
//

import Foundation

class CRUDCevap : Codable {
    var success:Int?
    var message:String?
}
